import { pgTable, text, serial, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  thumbnail: text("thumbnail"),
  songs: jsonb("songs").$type<Song[]>().notNull().default([])
});

export const insertPlaylistSchema = createInsertSchema(playlists).pick({
  name: true,
  description: true,
  thumbnail: true
});

export type Song = {
  id: string;
  title: string;
  thumbnail: string;
  duration: string;
  artist: string;
};

export type Playlist = typeof playlists.$inferSelect;
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;

export const songSchema = z.object({
  id: z.string(),
  title: z.string(),
  thumbnail: z.string(),
  duration: z.string(),
  artist: z.string()
});

export const updatePlaylistSchema = z.object({
  songs: z.array(songSchema)
});
