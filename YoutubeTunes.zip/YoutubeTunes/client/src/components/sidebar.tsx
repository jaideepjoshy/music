import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, Search, PlusCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import type { Playlist } from "@shared/schema";

export default function Sidebar() {
  const [location] = useLocation();
  const { toast } = useToast();

  const { data: playlists } = useQuery<Playlist[]>({
    queryKey: ["/api/playlists"]
  });

  const createPlaylist = async () => {
    try {
      const res = await fetch("/api/playlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: "New Playlist",
          description: "My new playlist",
          thumbnail: "https://images.unsplash.com/photo-1587731556938-38755b4803a6"
        })
      });

      if (!res.ok) throw new Error("Failed to create playlist");

      toast({
        title: "Created new playlist",
        description: "Start adding songs to your playlist"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not create playlist",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="flex items-center justify-between h-16 px-6">
      <div className="flex items-center gap-6">
        <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
          Hear'It
        </h1>

        <nav className="flex items-center gap-2">
          <Link href="/">
            <Button
              variant={location === "/" ? "default" : "ghost"}
              size="sm"
              className="gap-2 font-medium"
            >
              <Home className="h-4 w-4" />
              Library
            </Button>
          </Link>

          <Link href="/search">
            <Button
              variant={location === "/search" ? "default" : "ghost"}
              size="sm"
              className="gap-2 font-medium"
            >
              <Search className="h-4 w-4" />
              Search
            </Button>
          </Link>
        </nav>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex -space-x-3">
          {playlists?.slice(0, 3).map((playlist) => (
            <Link key={playlist.id} href={`/playlist/${playlist.id}`}>
              <div className="relative group">
                <img
                  src={playlist.thumbnail || ""}
                  alt={playlist.name}
                  className="w-8 h-8 rounded-full border-2 border-background ring-2 ring-primary/10 cursor-pointer transition-all duration-300 group-hover:scale-110 group-hover:ring-primary/30"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 rounded-full transition-colors duration-300" />
              </div>
            </Link>
          ))}
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={createPlaylist}
          className="hover:bg-primary/10 transition-colors duration-300"
        >
          <PlusCircle className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}