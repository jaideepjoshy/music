import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, MoreVertical } from "lucide-react";
import type { Playlist } from "@shared/schema";
import { Link } from "wouter";

interface PlaylistCardProps {
  playlist: Playlist;
}

export function PlaylistCard({ playlist }: PlaylistCardProps) {
  return (
    <Card className="group relative overflow-hidden transition-all hover:bg-accent">
      <CardHeader className="p-4">
        <div className="aspect-square mb-3 overflow-hidden rounded-md">
          <img
            src={playlist.thumbnail}
            alt={playlist.name}
            className="h-full w-full object-cover transition-all group-hover:scale-105"
          />
        </div>
        <CardTitle className="line-clamp-1">{playlist.name}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="line-clamp-2 text-sm text-muted-foreground">
          {playlist.description || `${playlist.songs.length} songs`}
        </p>
        
        <div className="absolute right-4 top-4 opacity-0 transition-opacity group-hover:opacity-100">
          <Button size="icon" variant="secondary">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </div>
        
        <Link href={`/playlist/${playlist.id}`}>
          <Button
            size="icon"
            className="absolute bottom-4 right-4 h-10 w-10 rounded-full opacity-0 transition-opacity group-hover:opacity-100"
          >
            <Play className="h-5 w-5" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
