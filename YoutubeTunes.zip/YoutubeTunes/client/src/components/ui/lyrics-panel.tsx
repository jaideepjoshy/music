import { useState, useEffect } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface LyricsPanelProps {
  artist?: string;
  title?: string;
}

export function LyricsPanel({ artist, title }: LyricsPanelProps) {
  const [lyrics, setLyrics] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchLyrics() {
      if (!artist || !title) {
        setLyrics("");
        return;
      }

      setLoading(true);
      try {
        const response = await fetch(
          `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`
        );
        
        if (!response.ok) {
          throw new Error("Could not find lyrics");
        }

        const data = await response.json();
        setLyrics(data.lyrics || "No lyrics found");
      } catch (error) {
        toast({
          title: "Could not load lyrics",
          description: "Try again later",
          variant: "destructive",
        });
        setLyrics("Lyrics not available");
      } finally {
        setLoading(false);
      }
    }

    fetchLyrics();
  }, [artist, title, toast]);

  if (!artist || !title) {
    return (
      <div className="h-full flex items-center justify-center text-white/60">
        Play a song to see lyrics
      </div>
    );
  }

  return (
    <div className="h-full">
      {loading ? (
        <div className="h-full flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-white/60" />
        </div>
      ) : (
        <ScrollArea className="h-full px-6">
          <div className="py-6">
            <h2 className="text-lg font-semibold mb-4">{title}</h2>
            <p className="text-sm text-white/80 whitespace-pre-line leading-relaxed">
              {lyrics}
            </p>
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
