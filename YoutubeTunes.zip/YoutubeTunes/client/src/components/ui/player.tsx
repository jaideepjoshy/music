import { useRef, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import YouTube from "react-youtube";
import { 
  Play, Pause, SkipBack, SkipForward, 
  Volume2, VolumeX 
} from "lucide-react";
import { usePlayer } from "@/contexts/PlayerContext";

export function Player() {
  const { currentSong, isPlaying, playSong, pauseSong } = usePlayer();
  const [volume, setVolume] = useState(100);
  const [progress, setProgress] = useState(0);
  const playerRef = useRef<any>(null);
  const { toast } = useToast();

  const togglePlay = () => {
    if (playerRef.current) {
      if (isPlaying) {
        playerRef.current.pauseVideo();
        pauseSong();
      } else {
        playerRef.current.playVideo();
        if (currentSong) playSong(currentSong);
      }

      toast({
        title: isPlaying ? "Paused" : "Playing",
        duration: 1000
      });
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (playerRef.current) {
      playerRef.current.setVolume(newVolume);
    }
  };

  const toggleMute = () => {
    const newVolume = volume === 0 ? 100 : 0;
    setVolume(newVolume);
    if (playerRef.current) {
      playerRef.current.setVolume(newVolume);
    }
  };

  // YouTube player options
  const opts = {
    height: '0',
    width: '0',
    playerVars: {
      autoplay: 1,
      controls: 0,
    },
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t border-white/5 bg-black/40 backdrop-blur-xl backdrop-saturate-200 supports-[backdrop-filter]:bg-black/40">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-8">
          <div className="flex items-center gap-4 w-1/3">
            {currentSong ? (
              <>
                <img 
                  src={currentSong.thumbnail}
                  alt="Now playing"
                  className="w-16 h-16 rounded-lg object-cover ring-1 ring-white/10"
                />
                <div>
                  <h3 className="font-medium line-clamp-1">{currentSong.title}</h3>
                  <p className="text-sm text-white/60">{currentSong.artist}</p>
                </div>
              </>
            ) : (
              <div className="text-sm text-white/60">
                No track selected
              </div>
            )}
          </div>

          <div className="flex flex-col items-center w-1/3">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-white/60 hover:text-white hover:bg-white/10"
                onClick={() => toast({ title: "Previous track" })}
              >
                <SkipBack className="h-5 w-5" />
              </Button>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 rounded-full bg-white/10 border-white/10 hover:bg-white/20 hover:border-white/20"
                onClick={togglePlay}
                disabled={!currentSong}
              >
                {isPlaying ? (
                  <Pause className="h-5 w-5" />
                ) : (
                  <Play className="h-5 w-5" />
                )}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="text-white/60 hover:text-white hover:bg-white/10"
                onClick={() => toast({ title: "Next track" })}
              >
                <SkipForward className="h-5 w-5" />
              </Button>
            </div>

            <div className="w-full mt-2 flex items-center gap-2">
              <span className="text-sm text-white/60">0:00</span>
              <Slider
                value={[progress]}
                max={100}
                step={1}
                className="w-full"
                onValueChange={([value]) => setProgress(value)}
              />
              <span className="text-sm text-white/60">{currentSong?.duration || "0:00"}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-1/3 justify-end">
            <Button
              variant="ghost"
              size="icon"
              className="text-white/60 hover:text-white hover:bg-white/10"
              onClick={toggleMute}
            >
              {volume === 0 ? (
                <VolumeX className="h-5 w-5" />
              ) : (
                <Volume2 className="h-5 w-5" />
              )}
            </Button>

            <Slider
              value={[volume]}
              max={100}
              step={1}
              className="w-32"
              onValueChange={handleVolumeChange}
            />
          </div>
        </div>
      </div>

      {currentSong && (
        <div style={{ display: 'none' }}>
          <YouTube
            videoId={currentSong.id}
            opts={opts}
            onReady={(event: any) => {
              playerRef.current = event.target;
              playerRef.current.setVolume(volume);
            }}
            onStateChange={(event: any) => {
              if (event.data === YouTube.PlayerState.ENDED) {
                pauseSong();
              }
            }}
          />
        </div>
      )}
    </div>
  );
}