import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, Play, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { usePlayer } from "@/contexts/PlayerContext";
import type { Song } from "@/contexts/PlayerContext";

export default function Search() {
  const [query, setQuery] = useState("");
  const { toast } = useToast();
  const { playSong } = usePlayer();

  const { data: results, isLoading } = useQuery({
    queryKey: [`/api/youtube/search?q=${query}`],
    enabled: query.length > 0
  });

  const handlePlay = (video: any) => {
    const song: Song = {
      id: video.id.videoId,
      title: video.snippet.title,
      artist: video.snippet.channelTitle,
      thumbnail: video.snippet.thumbnails.high.url,
      duration: "0:00" // We'll get this from a separate API call if needed
    };

    playSong(song);
    toast({ 
      title: "Now Playing", 
      description: song.title 
    });
  };

  const addToPlaylist = async (video: any) => {
    const song = {
      id: video.id.videoId,
      title: video.snippet.title,
      artist: video.snippet.channelTitle,
      thumbnail: video.snippet.thumbnails.high.url,
      duration: "0:00"
    };

    // Example: Add to the first playlist
    const playlists = await queryClient.fetchQuery({
      queryKey: ["/api/playlists"]
    });

    if (playlists && playlists.length > 0) {
      const playlist = playlists[0];
      const updatedSongs = [...playlist.songs, song];

      try {
        await fetch(`/api/playlists/${playlist.id}/songs`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ songs: updatedSongs })
        });

        toast({
          title: "Added to playlist",
          description: `Added "${song.title}" to ${playlist.name}`
        });

        // Invalidate playlists cache
        queryClient.invalidateQueries({ queryKey: ["/api/playlists"] });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to add song to playlist",
          variant: "destructive"
        });
      }
    } else {
      toast({
        title: "No playlist available",
        description: "Create a playlist first",
        variant: "destructive"
      });
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Search</h1>

      <div className="flex gap-4 mb-8">
        <div className="relative flex-1">
          <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search songs..."
            className="pl-9"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex gap-4 items-center">
              <div className="w-16 h-16 bg-muted rounded animate-pulse" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-1/3 bg-muted rounded animate-pulse" />
                <div className="h-3 w-1/4 bg-muted rounded animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {results?.items?.map((video: any) => (
            <div key={video.id.videoId} className="flex gap-4 items-center group">
              <img
                src={video.snippet.thumbnails.default.url}
                alt={video.snippet.title}
                className="w-16 h-16 object-cover rounded"
              />
              <div className="flex-1">
                <h3 className="font-medium line-clamp-1">{video.snippet.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {video.snippet.channelTitle}
                </p>
              </div>
              <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => handlePlay(video)}
                >
                  <Play className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => addToPlaylist(video)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}