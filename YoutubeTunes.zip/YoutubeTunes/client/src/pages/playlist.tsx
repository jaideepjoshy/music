import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Play, MoreVertical } from "lucide-react";
import type { Playlist } from "@shared/schema";

export default function PlaylistPage() {
  const { id } = useParams();
  
  const { data: playlist, isLoading } = useQuery<Playlist>({
    queryKey: [`/api/playlists/${id}`]
  });

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-8">
        <div className="flex gap-8">
          <div className="w-48 h-48 bg-muted rounded-lg" />
          <div className="flex-1 space-y-4">
            <div className="h-8 w-1/4 bg-muted rounded" />
            <div className="h-4 w-1/3 bg-muted rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!playlist) return null;

  return (
    <div>
      <div className="flex gap-8 mb-8">
        <img
          src={playlist.thumbnail}
          alt={playlist.name}
          className="w-48 h-48 object-cover rounded-lg"
        />
        <div className="flex-1">
          <h1 className="text-3xl font-bold mb-4">{playlist.name}</h1>
          <p className="text-muted-foreground mb-6">
            {playlist.description || `${playlist.songs.length} songs`}
          </p>
          <div className="flex gap-4">
            <Button size="lg" className="gap-2">
              <Play className="h-5 w-5" /> Play
            </Button>
            <Button variant="outline" size="icon">
              <MoreVertical className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        {playlist.songs.map((song) => (
          <div
            key={song.id}
            className="flex items-center gap-4 p-2 rounded-lg hover:bg-accent group"
          >
            <img
              src={song.thumbnail}
              alt={song.title}
              className="w-12 h-12 object-cover rounded"
            />
            <div className="flex-1">
              <h3 className="font-medium">{song.title}</h3>
              <p className="text-sm text-muted-foreground">{song.artist}</p>
            </div>
            <span className="text-sm text-muted-foreground">{song.duration}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
