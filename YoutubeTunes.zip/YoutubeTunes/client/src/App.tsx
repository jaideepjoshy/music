import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Search from "@/pages/search";
import Playlist from "@/pages/playlist";
import Sidebar from "@/components/sidebar";
import { Player } from "@/components/ui/player";
import { PlayerProvider } from "@/contexts/PlayerContext";

function Router() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top navigation with glass effect */}
      <nav className="fixed top-0 left-0 right-0 border-b border-white/5 bg-black/40 backdrop-blur-xl backdrop-saturate-200 z-50 supports-[backdrop-filter]:bg-black/40">
        <div className="max-w-7xl mx-auto">
          <Sidebar />
        </div>
      </nav>

      {/* Main content with proper spacing */}
      <main className="max-w-7xl mx-auto px-6 pt-24 pb-32">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/search" component={Search} />
          <Route path="/playlist/:id" component={Playlist} />
          <Route component={NotFound} />
        </Switch>
      </main>

      <Player />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <PlayerProvider>
        <Router />
        <Toaster />
      </PlayerProvider>
    </QueryClientProvider>
  );
}

export default App;