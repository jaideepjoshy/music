import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPlaylistSchema, updatePlaylistSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // YouTube API routes
  app.get("/api/youtube/search", async (req, res) => {
    const query = req.query.q as string;
    if (!query) {
      return res.status(400).json({ message: "Search query required" });
    }

    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(
          query
        )}&type=video&key=${process.env.YOUTUBE_API_KEY}`
      );
      
      if (!response.ok) {
        throw new Error("YouTube API error");
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to search YouTube videos" });
    }
  });

  // Playlist routes
  app.get("/api/playlists", async (_req, res) => {
    const playlists = await storage.getPlaylists();
    res.json(playlists);
  });

  app.get("/api/playlists/:id", async (req, res) => {
    const playlist = await storage.getPlaylist(Number(req.params.id));
    if (!playlist) {
      return res.status(404).json({ message: "Playlist not found" });
    }
    res.json(playlist);
  });

  app.post("/api/playlists", async (req, res) => {
    const result = insertPlaylistSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid playlist data" });
    }

    const playlist = await storage.createPlaylist(result.data);
    res.status(201).json(playlist);
  });

  app.patch("/api/playlists/:id/songs", async (req, res) => {
    const result = updatePlaylistSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid songs data" });
    }

    const playlist = await storage.updatePlaylistSongs(
      Number(req.params.id),
      result.data.songs
    );

    if (!playlist) {
      return res.status(404).json({ message: "Playlist not found" });
    }

    res.json(playlist);
  });

  app.delete("/api/playlists/:id", async (req, res) => {
    await storage.deletePlaylist(Number(req.params.id));
    res.status(204).send();
  });

  const httpServer = createServer(app);
  return httpServer;
}
