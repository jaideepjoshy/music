import { playlists, type Playlist, type InsertPlaylist, type Song } from "@shared/schema";

export interface IStorage {
  getPlaylists(): Promise<Playlist[]>;
  getPlaylist(id: number): Promise<Playlist | undefined>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  updatePlaylistSongs(id: number, songs: Song[]): Promise<Playlist | undefined>;
  deletePlaylist(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private playlists: Map<number, Playlist>;
  private currentId: number;

  constructor() {
    this.playlists = new Map();
    this.currentId = 1;
  }

  async getPlaylists(): Promise<Playlist[]> {
    return Array.from(this.playlists.values());
  }

  async getPlaylist(id: number): Promise<Playlist | undefined> {
    return this.playlists.get(id);
  }

  async createPlaylist(insertPlaylist: InsertPlaylist): Promise<Playlist> {
    const id = this.currentId++;
    const playlist: Playlist = { ...insertPlaylist, id, songs: [] };
    this.playlists.set(id, playlist);
    return playlist;
  }

  async updatePlaylistSongs(id: number, songs: Song[]): Promise<Playlist | undefined> {
    const playlist = this.playlists.get(id);
    if (!playlist) return undefined;
    
    const updated = { ...playlist, songs };
    this.playlists.set(id, updated);
    return updated;
  }

  async deletePlaylist(id: number): Promise<void> {
    this.playlists.delete(id);
  }
}

export const storage = new MemStorage();
